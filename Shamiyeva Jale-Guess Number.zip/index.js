const btn = document.getElementById("btn");
const prompt_box = document.getElementById("prompt_box");
const promt_txt = document.getElementById("promt_txt");
const txt = document.getElementById("txt");
const num = document.getElementById("num");
let chancesTxt = document.getElementById("chancesTxt");
let randomNumber = Math.floor(Math.random() * 10) + 1;


let number;
let Chances = 3;
chancesTxt.innerHTML = "Yoxlamaq şansınız: " + Chances;


btn.addEventListener("click", (e) => {
  e.preventDefault();
  console.log(num.value);
  Chances--;
  chancesTxt.innerHTML = "Yoxlamaq şansınız: " + Chances;
  if (Chances == 0) {
    activateBox("Uduzdunuz!");
  }
  number = num.value;
  checkNum(number);
  num.value = "";
});

function checkNum(number) {
  if (number == randomNumber) {
    activateBox("Qalibsiniz!");
  } else if (number > randomNumber) {
    txt.innerHTML = "Daha kiçik rəqəm daxil edin";
  } else {
    txt.innerHTML = "Daha böyük rəqəm daxil edin";
  }


  }


function activateBox(e) {
  prompt_box.classList.add("active");
  promt_txt.innerHTML = e + "Axtarılan ədəd:" + randomNumber;
  randomNumber = Math.floor(Math.random() * 10) + 1;
 
}
function play(e) {
  prompt_box.classList.remove("active");
  Chances = 3;
  txt.innerHTML = "";
  chancesTxt.innerHTML = "Yoxlamaq şansınız: " + Chances;
}